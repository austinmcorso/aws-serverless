const processImage = require('./process_image');
const upload = require('./upload');

module.exports = {
  processImage,
  upload,
};
