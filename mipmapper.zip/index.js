const processImage = require('./process_image').processImage;
const upload = require('./upload');

module.exports = {
  processImage,
  upload,
};
