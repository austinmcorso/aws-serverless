const processImage = require('./process_image').processImage;
const upload = require('./upload_image');

module.exports = {
  processImage,
  upload,
};
